
  README
  ######

  Welcome to the notTV MVP (Minimum Viable Product).
  not.tv

  Thank you for taking the time to trial, test, and/or contribute
  to our app. We support freedom, cooperation, creativity
  and community. We also strive for world class. Let's
  work to keep the code and product the best in the world.

  - Travis Michael Ernest Cross, tec21 (October 7, 2022)
    @travismichaelcross

  #################################

  1. Images included get unzipped to /storage/app/public/images
     "logo_black_311.png"
     "logo_white_512.png"
     "EBU_Colorbars.svg.png"
     "Ping.png"
     "logo_white.svg"

     2499  2024-02-09 21:33   README.txt
     3310  2022-10-07 22:24   storage/app/public/images/EBU_Colorbars.svg.png
    97422  2022-10-07 23:08   storage/app/public/images/Ping.png
    13866  2022-04-09 03:39   storage/app/public/images/logo_black_311.png
    26851  2022-06-12 03:22   storage/app/public/images/logo_white_512.png
     2078  2024-02-03 19:55   .env.working.example
     4566  2024-03-27 20:31   storage/app/public/images/logo_white.svg

  NOTE: the images are required before you seed the database.

  2. Setup the .env file

  3. Add ‘client_max_body_size xxM’ inside the http section in /etc/nginx/nginx.conf, where xx is the size (in megabytes) that you want to allow.

  3. Run the storage:link
    - $ php artisan storage:link

  4. Seed the database:
    - $ php artisan migrate
    - $ php artisan db:seed --class=FirstRunSeeder

  An Administrator account will be created:
       email: admin@not.tv
       password: nottv123

  5. Change the CDN_Endpoint and Cloud Folder in the Admin Settings.

  #################################

    Additional Seeders:
        - $ php artisan db:seed --class=UserSeeder
        - $ php artisan db:seed --class=CreatorSeeder
        - $ php artisan db:seed --class=TeamSeeder
        - $ php artisan db:seed --class=TeamMemberSeeder
        - $ php artisan db:seed --class=ShowSeeder
        - $ php artisan db:seed --class=ShowEpisodeSeeder
        - $ php artisan db:seed --class=MovieSeeder
        - $ php artisan db:seed --class=MasterSeeder (sets up categories)

  User Accounts that get created with the UserSeeder:
      1.
         email: user@not.tv
         password: nottv123
      2.
         email: subscriber@not.tv
         password: nottv123
      3.
         email: vip@not.tv
         password: nottv123
      4.
         email: creator@not.tv
         password: nottv123

  ################################

Setting up notTV from a Git Repo:

-> Unzip README.zip (it will add images to the /storage/app/public/images folder)
-> install PHP 8.1
-> PHP Extensions, curl, mbstring, ...
-> install composer
-> Composer update
-> create .env file
	(modify .env.example)
	APP_NAME
	DB
	PUSHER LOCAL DEV

-> sail up
-> sail artisan migrate
-> sail artisan db:seed



use this command to resave this file:
zip README.zip storage/app/public/images/* README.txt

