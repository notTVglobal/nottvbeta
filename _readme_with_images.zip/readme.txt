
  README
  ######
  
  Welcome to the notTV Beta Prototype.
  not.tv
  
  Thank you for taking the time to trial, test, contribute
  to our app. We support freedom, cooperation, creativity
  and community. We also strive for world class. Let's
  work to keep the code and product the best in the world.
  
  - Travis Michael Ernest Cross, tec21 (October 7, 2022)
  
  #################################

  1. Unzip these images to /storage/app/public/images
     "logo_black_311.png"
     "logo_white_512.png"
     "EBU_Colorbars.svg.png"
     "Ping.png"
     
  2. Delete this readme.txt

  3. Run:

    - $ php artisan migrate
    - $ php artisan db:seed

  NOTE: the images are required before you seed the database.

  #################################

  5 user accounts will be created:

  #################################

  1.
     email: admin@not.tv
     password: nottv123

  2.
     email: user@not.tv
     password: nottv123

  3.
     email: subscriber@not.tv
     password: nottv123

  4.
     email: vip@not.tv
     password: nottv123

  5.
     email: creator@not.tv
     password: nottv123

  ################################


